#!/usr/bin/env python3
"""Regression: real-CBMC acceptance fixtures use loop-specific assigns clauses.

CBMC loop contracts require __CPROVER_loop_assigns on loops. Function-contract
__CPROVER_assigns must not be attached to loop annotations in the acceptance
fixture, because goto-cc 6.9.0 rejects that grammar.
"""
from __future__ import annotations

import os
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ACCEPT = ROOT / "tests" / "accept_real_cbmc_69.py"

FAKE_TOOL = r'''#!/usr/bin/env python3
import json, os, shutil, sys
from pathlib import Path
name = Path(sys.argv[0]).name
args = sys.argv[1:]
if "--version" in args:
    print(f"{name} version 6.9.0")
    raise SystemExit(0)
if name == "goto-cc":
    source = next((Path(x) for x in args if x.endswith(".c")), None)
    if source is None:
        raise SystemExit(93)
    text = source.read_text(encoding="utf-8")
    if source.name in {"loop_contract.c", "hybrid_contract.c"}:
        if "__CPROVER_loop_assigns(" not in text:
            print("missing __CPROVER_loop_assigns", file=sys.stderr)
            raise SystemExit(94)
        # The acceptance fixtures contain function contracts too, so only
        # reject the exact loop-annotation spelling used by the prior defect.
        bad = "__CPROVER_loop_invariant" in text and "\n    __CPROVER_assigns(i," in text
        if bad:
            print("function-level __CPROVER_assigns attached to loop", file=sys.stderr)
            raise SystemExit(95)
    if source.name.startswith("invalid_"):
        raise SystemExit(1)
    if "-o" in args:
        Path(args[args.index("-o") + 1]).write_text("fake goto binary\n", encoding="utf-8")
    raise SystemExit(0)
if name == "goto-instrument":
    shutil.copyfile(Path(args[-2]), Path(args[-1]))
    raise SystemExit(0)
if name == "cbmc":
    print(json.dumps([{"description": "TRACE_CLAIM::REAL_FUNCTION::C01 TRACE_CLAIM::REAL_LOOP::C01 TRACE_CLAIM::REAL_HYBRID::C01"}]))
    raise SystemExit(0)
raise SystemExit(99)
'''


def main() -> int:
    source = ACCEPT.read_text(encoding="utf-8")
    assert source.count("__CPROVER_loop_assigns(i, __CPROVER_object_upto(a, sizeof(a)))") == 2
    assert "\n    __CPROVER_assigns(i, __CPROVER_object_upto(a, sizeof(a)))" not in source

    with tempfile.TemporaryDirectory(prefix="verify_cbmc_loop_clause_") as td:
        t = Path(td)
        bindir = t / "bin"
        bindir.mkdir()
        for name in ("goto-cc", "goto-instrument", "cbmc"):
            tool = bindir / name
            tool.write_text(FAKE_TOOL, encoding="utf-8")
            tool.chmod(0o755)
        report = t / "acceptance.json"
        env = os.environ.copy()
        env.update({
            "PATH": str(bindir) + os.pathsep + env.get("PATH", ""),
            "REQUIRE_REAL_CBMC": "1",
            "CBMC_ACCEPTANCE_REPORT": str(report),
            "PYTHONDONTWRITEBYTECODE": "1",
        })
        proc = subprocess.run(
            [sys.executable, str(ACCEPT)], cwd=ROOT, env=env,
            text=True, capture_output=True, timeout=60, check=False,
        )
        assert proc.returncode == 0, proc.stdout + "\n" + proc.stderr
        assert report.is_file()
    print("REAL CBMC LOOP CLAUSE SYNTAX: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
