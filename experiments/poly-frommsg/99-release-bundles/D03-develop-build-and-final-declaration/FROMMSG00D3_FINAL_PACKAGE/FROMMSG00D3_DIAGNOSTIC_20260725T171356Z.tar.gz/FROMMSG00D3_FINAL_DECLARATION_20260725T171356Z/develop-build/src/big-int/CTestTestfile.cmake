# CMake generated Testfile for 
# Source directory: /src/src/big-int
# Build directory: /build/src/big-int
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
