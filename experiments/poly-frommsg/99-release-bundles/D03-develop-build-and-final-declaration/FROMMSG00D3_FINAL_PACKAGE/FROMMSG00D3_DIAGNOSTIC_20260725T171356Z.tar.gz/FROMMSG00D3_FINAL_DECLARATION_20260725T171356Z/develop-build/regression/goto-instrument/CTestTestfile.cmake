# CMake generated Testfile for 
# Source directory: /src/regression/goto-instrument
# Build directory: /build/regression/goto-instrument
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test(goto-instrument-CORE "perl" "/src/regression/test.pl" "-e" "-p" "-c" "/src/regression/goto-instrument/chain.sh /build/bin/goto-cc /build/bin/goto-instrument /build/bin/cbmc false" "-C")
set_tests_properties(goto-instrument-CORE PROPERTIES  LABELS "CORE;CBMC" TIMEOUT "1200" WORKING_DIRECTORY "/src/regression/goto-instrument" _BACKTRACE_TRIPLES "/src/regression/CMakeLists.txt;4;add_test;/src/regression/CMakeLists.txt;50;add_test_pl_profile;/src/regression/goto-instrument/CMakeLists.txt;7;add_test_pl_tests;/src/regression/goto-instrument/CMakeLists.txt;0;")
add_test(goto-instrument-THOROUGH "perl" "/src/regression/test.pl" "-e" "-p" "-c" "/src/regression/goto-instrument/chain.sh /build/bin/goto-cc /build/bin/goto-instrument /build/bin/cbmc false" "-T")
set_tests_properties(goto-instrument-THOROUGH PROPERTIES  LABELS "THOROUGH;CBMC" TIMEOUT "1200" WORKING_DIRECTORY "/src/regression/goto-instrument" _BACKTRACE_TRIPLES "/src/regression/CMakeLists.txt;4;add_test;/src/regression/CMakeLists.txt;51;add_test_pl_profile;/src/regression/goto-instrument/CMakeLists.txt;7;add_test_pl_tests;/src/regression/goto-instrument/CMakeLists.txt;0;")
add_test(goto-instrument-FUTURE "perl" "/src/regression/test.pl" "-e" "-p" "-c" "/src/regression/goto-instrument/chain.sh /build/bin/goto-cc /build/bin/goto-instrument /build/bin/cbmc false" "-F")
set_tests_properties(goto-instrument-FUTURE PROPERTIES  LABELS "FUTURE;CBMC" TIMEOUT "1200" WORKING_DIRECTORY "/src/regression/goto-instrument" _BACKTRACE_TRIPLES "/src/regression/CMakeLists.txt;4;add_test;/src/regression/CMakeLists.txt;52;add_test_pl_profile;/src/regression/goto-instrument/CMakeLists.txt;7;add_test_pl_tests;/src/regression/goto-instrument/CMakeLists.txt;0;")
add_test(goto-instrument-KNOWNBUG "perl" "/src/regression/test.pl" "-e" "-p" "-c" "/src/regression/goto-instrument/chain.sh /build/bin/goto-cc /build/bin/goto-instrument /build/bin/cbmc false" "-K")
set_tests_properties(goto-instrument-KNOWNBUG PROPERTIES  LABELS "KNOWNBUG;CBMC" TIMEOUT "1200" WORKING_DIRECTORY "/src/regression/goto-instrument" _BACKTRACE_TRIPLES "/src/regression/CMakeLists.txt;4;add_test;/src/regression/CMakeLists.txt;53;add_test_pl_profile;/src/regression/goto-instrument/CMakeLists.txt;7;add_test_pl_tests;/src/regression/goto-instrument/CMakeLists.txt;0;")
