# SUB-T1 Novelty and Prior-Work Comparison

## 1. What is established directly by the frozen repository comparison

At frozen mlkem-native commit:

`d9613cf60de3132d32475c102d8c2781d84feb34`

The repository's dedicated harness is only:

```c
#include "poly.h"

void harness(void)
{
  mlk_poly *r, *b;
  mlk_poly_sub(r, b);
}
```

Its Makefile sets:

```text
CHECK_FUNCTION_CONTRACTS=mlk_poly_sub
APPLY_LOOP_CONTRACTS=on
```

The frozen repository harness therefore calls `mlk_poly_sub` once and the repository proof checks its existing function contract with loop contracts applied. It does not call `mlk_poly_reduce`, does not compute the independent shifted modular oracle, and does not state the SUB-T1 coefficientwise semantic-composition theorem.

Original files are preserved in `repository_comparison/` with SHA-256 values:

- repository harness: `12d6a569b8a0bc6a4fc9340f1378f28e11c94beb43730b291161d6a24f8f67d1`
- repository Makefile: `d576e9ca8f1c952e79ae0b21d93b768a9d0d14b38584e76e953a800253afece8`

This establishes a **repository-level distinction**, not worldwide novelty.

## 2. Clean-room and authorship record

The production source packet was collected without repository proof harnesses, proof reports, proof JSON, or dedicated `poly_sub` proof source. The SUB-T1 and SUB-T2 theorem families were preregistered before inspection of the repository's dedicated `poly_sub` harness. The record also discloses that the repository proof Makefile had been exposed during pre-freeze review and that generic old safety-result lines were accidentally seen; therefore ordinary pointer, bounds, and overflow safety are not eligible novelty claims.

The exact source packet, source manifest, theorem preregistration, architecture freeze, and sidecars are under `provenance/`.

## 3. Wider prior work prevents broad first-proof claims

Prior machine-checked functional-correctness work exists for Kyber implementations written in Jasmin and proved against an EasyCrypt specification. See:

- Almeida et al., “Formally verifying Kyber: Episode IV: Implementation correctness,” TCHES 2023(3), pp. 164–193, DOI: `10.46586/tches.v2023.i3.164-193`.
- NIST CSRC presentation, “Formally Verifying Kyber Part I: Functional Correctness,” 19 April 2023: `https://csrc.nist.gov/presentations/2023/formally-verifying-kyber-part-i-functional-correct`.

A 2026 Amazon Science description of mlkem-native characterises its C-level CBMC work as memory- and type-safety verification while describing separate functional-correctness proofs for optimized assembly components:

`https://www.amazon.science/blog/verifying-and-optimizing-post-quantum-cryptography-at-amazon`

These sources mean SUB-T1 must not be presented as the first formal proof of Kyber/ML-KEM polynomial arithmetic or as the first formally verified Kyber/ML-KEM implementation.

## 4. Defensible current contribution wording

> This work independently developed and verified a body-level CBMC semantic-composition artefact for frozen mlkem-native commit `d9613cf60de3132d32475c102d8c2781d84feb34`. The artefact establishes that production polynomial subtraction followed by canonical reduction agrees coefficientwise with an independent modular oracle for every representable signed 16-bit coefficient difference. No equivalent artefact was identified in the repository's dedicated `poly_sub` proof. Wider novelty remains subject to documented public-code and literature comparison.

## 5. Claims not established by this packet

This packet does not establish:

- a new mathematical theorem;
- the first formal proof of ML-KEM subtraction;
- the first formal proof of Kyber polynomial arithmetic;
- the first CBMC proof worldwide of an equivalent property;
- absence of equivalent unpublished, unindexed, or differently formulated artefacts; or
- mutation sensitivity or non-vacuity beyond the evidence explicitly included here.

## 6. Remaining hardening before a stronger novelty claim

The next independent gates should be kept separate from this successful theorem result:

1. non-vacuity and reachability evidence;
2. mutation/negative-control sensitivity;
3. a documented public-code equivalence search;
4. a documented literature equivalence search; and
5. supervisor review of the theorem's scientific value and wording.

This document is a bounded comparison note, not a systematic literature review.
