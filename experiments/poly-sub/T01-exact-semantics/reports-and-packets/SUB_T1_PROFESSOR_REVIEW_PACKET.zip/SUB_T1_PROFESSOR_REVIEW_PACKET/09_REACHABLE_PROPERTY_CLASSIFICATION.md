# SUB-T1 Reachable Property Classification

## Classification result

- Total properties reported by CBMC: **361**
- Properties attached to the confirmed reachable SUB-T1 execution chain: **89**
- Remaining properties from unrelated retained functions in the full `poly.c` model: **272**
- Reachable-chain successes: **89/89**

The 272 remaining successes are preserved in the complete JSON but are **not** counted as additional SUB-T1 theorem evidence.

## Method

The accepted preflight produced a reachable call graph from the frozen GOTO model and a reachable-only inspection model. Property records from the complete CBMC JSON were classified by their `sourceLocation.function`. Functions on the reachable theorem path that had instrumented properties were retained. Reachable inline/wrapper functions with no reported property were not artificially added to the count.

Authoritative supporting files:

- `raw_evidence/preflight_selected/build/reachable_call_graph.txt`
- `raw_evidence/preflight_selected/build/actual_loop_ids.txt`
- `raw_evidence/final_result/frozen_inputs/show_cbmc_properties.txt`
- `08_CBMC_COMPLETE_RESULT.json`

## Category counts

| CBMC property class | Count |
|---|---:|
| assertion | 20 |
| array bounds | 21 |
| overflow | 24 |
| pointer dereference | 24 |

The 24 `overflow` records include arithmetic and conversion checks. The 24 pointer records are CBMC pointer-dereference validity obligations.

## Reachable functions with reported properties

| Function | Count |
|---|---:|
| `main` | 38 |
| `mlk_barrett_reduce` | 5 |
| `mlk_cast_int32_to_uint16` | 1 |
| `mlk_ct_cmask_nonzero_u16` | 1 |
| `mlk_ct_get_optblocker_i32` | 1 |
| `mlk_ct_sel_int16` | 1 |
| `mlk_poly_reduce_c` | 15 |
| `mlk_scalar_signed_to_unsigned_q` | 2 |
| `mlk_sub00g_r2_poly_sub` | 17 |
| `sub_t1_check_machine_model` | 8 |

## Complete list of the 89 theorem-relevant property records

| # | Property identifier | Class | Function | Status | Description |
|---:|---|---|---|---|---|
| 1 | `main.assertion.1` | assertion | `main` | SUCCESS | SUB_T1_PARAMETER: MLKEM_N must equal FIPS_N |
| 2 | `main.assertion.2` | assertion | `main` | SUCCESS | SUB_T1_PARAMETER: MLKEM_Q must equal FIPS_Q |
| 3 | `main.array_bounds.1` | array bounds | `main` | SUCCESS | array 'A0'.coeffs upper bound in A0.coeffs[(signed long int)i] |
| 4 | `main.array_bounds.2` | array bounds | `main` | SUCCESS | array 'B0'.coeffs upper bound in B0.coeffs[(signed long int)i] |
| 5 | `main.overflow.1` | overflow | `main` | SUCCESS | arithmetic overflow on unsigned + in i + 1u |
| 6 | `main.array_bounds.3` | array bounds | `main` | SUCCESS | array 'saved_A0'.coeffs upper bound in saved_A0.coeffs[(signed long int)i] |
| 7 | `main.array_bounds.4` | array bounds | `main` | SUCCESS | array 'saved_B0'.coeffs upper bound in saved_B0.coeffs[(signed long int)i] |
| 8 | `main.overflow.2` | overflow | `main` | SUCCESS | arithmetic overflow on signed - in (int32_t)saved_A0.coeffs[(signed long int)i] - (int32_t)saved_B0.coeffs[(signed long int)i] |
| 9 | `main.overflow.3` | overflow | `main` | SUCCESS | arithmetic overflow on unsigned + in i + 1u |
| 10 | `main.array_bounds.5` | array bounds | `main` | SUCCESS | array 'LB'.coeffs upper bound in LB.coeffs[(signed long int)i] |
| 11 | `main.array_bounds.6` | array bounds | `main` | SUCCESS | array 'LB_before_sub'.coeffs upper bound in LB_before_sub.coeffs[(signed long int)i] |
| 12 | `main.assertion.3` | assertion | `main` | SUCCESS | SUB_T1_FRAME: subtraction must not modify LB |
| 13 | `main.array_bounds.7` | array bounds | `main` | SUCCESS | array 'A0'.coeffs upper bound in A0.coeffs[(signed long int)i] |
| 14 | `main.array_bounds.8` | array bounds | `main` | SUCCESS | array 'saved_A0'.coeffs upper bound in saved_A0.coeffs[(signed long int)i] |
| 15 | `main.assertion.4` | assertion | `main` | SUCCESS | SUB_T1_FRAME: subtraction must not modify A0 |
| 16 | `main.array_bounds.9` | array bounds | `main` | SUCCESS | array 'B0'.coeffs upper bound in B0.coeffs[(signed long int)i] |
| 17 | `main.array_bounds.10` | array bounds | `main` | SUCCESS | array 'saved_B0'.coeffs upper bound in saved_B0.coeffs[(signed long int)i] |
| 18 | `main.assertion.5` | assertion | `main` | SUCCESS | SUB_T1_FRAME: subtraction must not modify B0 |
| 19 | `main.overflow.4` | overflow | `main` | SUCCESS | arithmetic overflow on unsigned + in i + 1u |
| 20 | `main.array_bounds.11` | array bounds | `main` | SUCCESS | array 'saved_A0'.coeffs upper bound in saved_A0.coeffs[(signed long int)i] |
| 21 | `main.array_bounds.12` | array bounds | `main` | SUCCESS | array 'saved_B0'.coeffs upper bound in saved_B0.coeffs[(signed long int)i] |
| 22 | `main.overflow.5` | overflow | `main` | SUCCESS | arithmetic overflow on signed - in (int32_t)saved_A0.coeffs[(signed long int)i] - (int32_t)saved_B0.coeffs[(signed long int)i] |
| 23 | `main.overflow.6` | overflow | `main` | SUCCESS | arithmetic overflow on signed + in d + (int32_t)(10 * 3329) |
| 24 | `main.overflow.7` | overflow | `main` | SUCCESS | arithmetic overflow on signed to unsigned type conversion in (uint32_t)(d + (int32_t)(10 * 3329)) |
| 25 | `main.array_bounds.13` | array bounds | `main` | SUCCESS | array 'L'.coeffs upper bound in L.coeffs[(signed long int)i] |
| 26 | `main.assertion.6` | assertion | `main` | SUCCESS | SUB_T1_SEMANTIC: output must be non-negative |
| 27 | `main.assertion.7` | assertion | `main` | SUCCESS | SUB_T1_SEMANTIC: output must be below FIPS_Q |
| 28 | `main.overflow.8` | overflow | `main` | SUCCESS | arithmetic overflow on signed to unsigned type conversion in (uint32_t)L.coeffs[(signed long int)i] |
| 29 | `main.assertion.8` | assertion | `main` | SUCCESS | SUB_T1_SEMANTIC: output must equal independent canonical oracle |
| 30 | `main.array_bounds.14` | array bounds | `main` | SUCCESS | array 'LB'.coeffs upper bound in LB.coeffs[(signed long int)i] |
| 31 | `main.array_bounds.15` | array bounds | `main` | SUCCESS | array 'LB_before_reduce'.coeffs upper bound in LB_before_reduce.coeffs[(signed long int)i] |
| 32 | `main.assertion.9` | assertion | `main` | SUCCESS | SUB_T1_FRAME: reduction must not modify LB |
| 33 | `main.assertion.10` | assertion | `main` | SUCCESS | SUB_T1_FRAME: final LB must equal saved B0 |
| 34 | `main.array_bounds.16` | array bounds | `main` | SUCCESS | array 'A0'.coeffs upper bound in A0.coeffs[(signed long int)i] |
| 35 | `main.assertion.11` | assertion | `main` | SUCCESS | SUB_T1_FRAME: final A0 must equal saved A0 |
| 36 | `main.array_bounds.17` | array bounds | `main` | SUCCESS | array 'B0'.coeffs upper bound in B0.coeffs[(signed long int)i] |
| 37 | `main.assertion.12` | assertion | `main` | SUCCESS | SUB_T1_FRAME: final B0 must equal saved B0 |
| 38 | `main.overflow.9` | overflow | `main` | SUCCESS | arithmetic overflow on unsigned + in i + 1u |
| 39 | `mlk_barrett_reduce.overflow.1` | overflow | `mlk_barrett_reduce` | SUCCESS | arithmetic overflow on signed * in magic * (signed int)a |
| 40 | `mlk_barrett_reduce.overflow.2` | overflow | `mlk_barrett_reduce` | SUCCESS | arithmetic overflow on signed + in magic * (signed int)a + ((int32_t)1 << 25) |
| 41 | `mlk_barrett_reduce.overflow.3` | overflow | `mlk_barrett_reduce` | SUCCESS | arithmetic overflow on signed * in t * 3329 |
| 42 | `mlk_barrett_reduce.overflow.4` | overflow | `mlk_barrett_reduce` | SUCCESS | arithmetic overflow on signed - in (signed int)a - t * 3329 |
| 43 | `mlk_barrett_reduce.overflow.5` | overflow | `mlk_barrett_reduce` | SUCCESS | arithmetic overflow on signed type conversion in (int16_t)((signed int)a - t * 3329) |
| 44 | `mlk_cast_int32_to_uint16.overflow.1` | overflow | `mlk_cast_int32_to_uint16` | SUCCESS | arithmetic overflow on signed to unsigned type conversion in (uint16_t)(x & (int32_t)65535) |
| 45 | `mlk_ct_cmask_nonzero_u16.overflow.1` | overflow | `mlk_ct_cmask_nonzero_u16` | SUCCESS | arithmetic overflow on signed unary minus in -((int32_t)x) |
| 46 | `mlk_ct_get_optblocker_i32.overflow.1` | overflow | `mlk_ct_get_optblocker_i32` | SUCCESS | arithmetic overflow on unsigned to signed type conversion in (int32_t)return_value_mlk_ct_get_optblocker_u64 |
| 47 | `mlk_ct_sel_int16.overflow.1` | overflow | `mlk_ct_sel_int16` | SUCCESS | arithmetic overflow on signed to unsigned type conversion in (uint16_t)((signed int)bu ^ (signed int)return_value_mlk_ct_cmask_nonzero_u16 & ((signed int)au ^ (signed int)bu)) |
| 48 | `mlk_poly_reduce_c.pointer_dereference.1` | pointer dereference | `mlk_poly_reduce_c` | SUCCESS | dereference failure: pointer NULL in r->coeffs |
| 49 | `mlk_poly_reduce_c.pointer_dereference.2` | pointer dereference | `mlk_poly_reduce_c` | SUCCESS | dereference failure: pointer invalid in r->coeffs |
| 50 | `mlk_poly_reduce_c.pointer_dereference.3` | pointer dereference | `mlk_poly_reduce_c` | SUCCESS | dereference failure: deallocated dynamic object in r->coeffs |
| 51 | `mlk_poly_reduce_c.pointer_dereference.4` | pointer dereference | `mlk_poly_reduce_c` | SUCCESS | dereference failure: dead object in r->coeffs |
| 52 | `mlk_poly_reduce_c.pointer_dereference.5` | pointer dereference | `mlk_poly_reduce_c` | SUCCESS | dereference failure: pointer outside object bounds in r->coeffs |
| 53 | `mlk_poly_reduce_c.pointer_dereference.6` | pointer dereference | `mlk_poly_reduce_c` | SUCCESS | dereference failure: invalid integer address in r->coeffs |
| 54 | `mlk_poly_reduce_c.array_bounds.1` | array bounds | `mlk_poly_reduce_c` | SUCCESS | array.coeffs dynamic object upper bound in r->coeffs[(signed long int)i] |
| 55 | `mlk_poly_reduce_c.pointer_dereference.7` | pointer dereference | `mlk_poly_reduce_c` | SUCCESS | dereference failure: pointer NULL in r->coeffs |
| 56 | `mlk_poly_reduce_c.pointer_dereference.8` | pointer dereference | `mlk_poly_reduce_c` | SUCCESS | dereference failure: pointer invalid in r->coeffs |
| 57 | `mlk_poly_reduce_c.pointer_dereference.9` | pointer dereference | `mlk_poly_reduce_c` | SUCCESS | dereference failure: deallocated dynamic object in r->coeffs |
| 58 | `mlk_poly_reduce_c.pointer_dereference.10` | pointer dereference | `mlk_poly_reduce_c` | SUCCESS | dereference failure: dead object in r->coeffs |
| 59 | `mlk_poly_reduce_c.pointer_dereference.11` | pointer dereference | `mlk_poly_reduce_c` | SUCCESS | dereference failure: pointer outside object bounds in r->coeffs |
| 60 | `mlk_poly_reduce_c.pointer_dereference.12` | pointer dereference | `mlk_poly_reduce_c` | SUCCESS | dereference failure: invalid integer address in r->coeffs |
| 61 | `mlk_poly_reduce_c.array_bounds.2` | array bounds | `mlk_poly_reduce_c` | SUCCESS | array.coeffs dynamic object upper bound in r->coeffs[(signed long int)i] |
| 62 | `mlk_poly_reduce_c.overflow.1` | overflow | `mlk_poly_reduce_c` | SUCCESS | arithmetic overflow on unsigned + in i + 1u |
| 63 | `mlk_scalar_signed_to_unsigned_q.overflow.1` | overflow | `mlk_scalar_signed_to_unsigned_q` | SUCCESS | arithmetic overflow on signed + in (signed int)c + 3329 |
| 64 | `mlk_scalar_signed_to_unsigned_q.overflow.2` | overflow | `mlk_scalar_signed_to_unsigned_q` | SUCCESS | arithmetic overflow on signed type conversion in (int16_t)((signed int)c + 3329) |
| 65 | `mlk_sub00g_r2_poly_sub.pointer_dereference.1` | pointer dereference | `mlk_sub00g_r2_poly_sub` | SUCCESS | dereference failure: pointer NULL in r->coeffs |
| 66 | `mlk_sub00g_r2_poly_sub.pointer_dereference.2` | pointer dereference | `mlk_sub00g_r2_poly_sub` | SUCCESS | dereference failure: pointer invalid in r->coeffs |
| 67 | `mlk_sub00g_r2_poly_sub.pointer_dereference.3` | pointer dereference | `mlk_sub00g_r2_poly_sub` | SUCCESS | dereference failure: deallocated dynamic object in r->coeffs |
| 68 | `mlk_sub00g_r2_poly_sub.pointer_dereference.4` | pointer dereference | `mlk_sub00g_r2_poly_sub` | SUCCESS | dereference failure: dead object in r->coeffs |
| 69 | `mlk_sub00g_r2_poly_sub.pointer_dereference.5` | pointer dereference | `mlk_sub00g_r2_poly_sub` | SUCCESS | dereference failure: pointer outside object bounds in r->coeffs |
| 70 | `mlk_sub00g_r2_poly_sub.pointer_dereference.6` | pointer dereference | `mlk_sub00g_r2_poly_sub` | SUCCESS | dereference failure: invalid integer address in r->coeffs |
| 71 | `mlk_sub00g_r2_poly_sub.array_bounds.1` | array bounds | `mlk_sub00g_r2_poly_sub` | SUCCESS | array.coeffs dynamic object upper bound in r->coeffs[(signed long int)i] |
| 72 | `mlk_sub00g_r2_poly_sub.pointer_dereference.7` | pointer dereference | `mlk_sub00g_r2_poly_sub` | SUCCESS | dereference failure: pointer NULL in b->coeffs |
| 73 | `mlk_sub00g_r2_poly_sub.pointer_dereference.8` | pointer dereference | `mlk_sub00g_r2_poly_sub` | SUCCESS | dereference failure: pointer invalid in b->coeffs |
| 74 | `mlk_sub00g_r2_poly_sub.pointer_dereference.9` | pointer dereference | `mlk_sub00g_r2_poly_sub` | SUCCESS | dereference failure: deallocated dynamic object in b->coeffs |
| 75 | `mlk_sub00g_r2_poly_sub.pointer_dereference.10` | pointer dereference | `mlk_sub00g_r2_poly_sub` | SUCCESS | dereference failure: dead object in b->coeffs |
| 76 | `mlk_sub00g_r2_poly_sub.pointer_dereference.11` | pointer dereference | `mlk_sub00g_r2_poly_sub` | SUCCESS | dereference failure: pointer outside object bounds in b->coeffs |
| 77 | `mlk_sub00g_r2_poly_sub.pointer_dereference.12` | pointer dereference | `mlk_sub00g_r2_poly_sub` | SUCCESS | dereference failure: invalid integer address in b->coeffs |
| 78 | `mlk_sub00g_r2_poly_sub.array_bounds.2` | array bounds | `mlk_sub00g_r2_poly_sub` | SUCCESS | array.coeffs dynamic object upper bound in b->coeffs[(signed long int)i] |
| 79 | `mlk_sub00g_r2_poly_sub.overflow.1` | overflow | `mlk_sub00g_r2_poly_sub` | SUCCESS | arithmetic overflow on signed - in (signed int)r->coeffs[(signed long int)i] - (signed int)b->coeffs[(signed long int)i] |
| 80 | `mlk_sub00g_r2_poly_sub.overflow.2` | overflow | `mlk_sub00g_r2_poly_sub` | SUCCESS | arithmetic overflow on signed type conversion in (int16_t)((signed int)r->coeffs[(signed long int)i] - (signed int)b->coeffs[(signed long int)i]) |
| 81 | `mlk_sub00g_r2_poly_sub.overflow.3` | overflow | `mlk_sub00g_r2_poly_sub` | SUCCESS | arithmetic overflow on unsigned + in i + 1u |
| 82 | `sub_t1_check_machine_model.assertion.1` | assertion | `sub_t1_check_machine_model` | SUCCESS | SUB_T1_MODEL: CHAR_BIT must be 8 |
| 83 | `sub_t1_check_machine_model.assertion.2` | assertion | `sub_t1_check_machine_model` | SUCCESS | SUB_T1_MODEL: short width must be 16 |
| 84 | `sub_t1_check_machine_model.assertion.3` | assertion | `sub_t1_check_machine_model` | SUCCESS | SUB_T1_MODEL: int width must be 32 |
| 85 | `sub_t1_check_machine_model.assertion.4` | assertion | `sub_t1_check_machine_model` | SUCCESS | SUB_T1_MODEL: int16_t width must be 16 |
| 86 | `sub_t1_check_machine_model.assertion.5` | assertion | `sub_t1_check_machine_model` | SUCCESS | SUB_T1_MODEL: int32_t width must be 32 |
| 87 | `sub_t1_check_machine_model.assertion.6` | assertion | `sub_t1_check_machine_model` | SUCCESS | SUB_T1_MODEL: pointer width must be 64 |
| 88 | `sub_t1_check_machine_model.assertion.7` | assertion | `sub_t1_check_machine_model` | SUCCESS | SUB_T1_MODEL: negative signed right shift must be arithmetic |
| 89 | `sub_t1_check_machine_model.assertion.8` | assertion | `sub_t1_check_machine_model` | SUCCESS | SUB_T1_MODEL: negative odd right shift must preserve sign |

## Integrity checks performed while building this packet

- The preflight property identifiers and final-result identifiers are identical and in the same order.
- Every one of the 89 reachable records has status `SUCCESS`.
- The complete result contains no failed or unknown properties.
- This classification does not convert the 272 unrelated successes into theorem evidence.
