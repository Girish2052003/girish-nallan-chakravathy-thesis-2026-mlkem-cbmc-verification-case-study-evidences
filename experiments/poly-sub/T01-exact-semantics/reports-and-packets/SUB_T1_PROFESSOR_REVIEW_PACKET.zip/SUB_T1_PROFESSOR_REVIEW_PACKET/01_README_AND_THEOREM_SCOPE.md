# SUB-T1 Professor Review Packet

## Purpose

This packet contains the complete evidence needed to review the successful SUB-T1 / Mode A / ML-KEM-768 CBMC theorem result before it is described as a thesis contribution.

## Frozen identity

- Repository: `mlkem-native`
- Commit: `d9613cf60de3132d32475c102d8c2781d84feb34`
- Production target: `mlkem/src/poly.c`
- Production functions: `mlk_poly_sub` followed by `mlk_poly_reduce`
- Parameter set: ML-KEM-768
- CBMC: 6.9.0
- Frozen harness SHA-256: `42c09c2f004d567d8b886058bd2304d960a219d36f0f6605b015966db3bc5682`
- Frozen GOTO-model SHA-256: `e9bef62631fbad4711d3eebf1ff8c48d5c2ea29d4dc4b4e9ef588ff6805260bb`
- Executed runner SHA-256: `746066213716d91b9753bcdf5bebc25aec3461ed4dd5a60bfe0d757504eeaabf`
- Accepted final result archive SHA-256: `054ca49dc569642c4e1395b9f0027dca01da440a6b8653885a1d448ba0ca9a96`

## Theorem

For every coefficient `i`, let `A[i]` and `B[i]` be arbitrary signed 16-bit values whose mathematical difference is representable in `int16_t`. The frozen harness executes retained production bodies:

```c
mlk_poly_sub(&L, &LB);
mlk_poly_reduce(&L);
```

and proves:

```text
0 <= L[i] < 3329
L[i] = (A[i] - B[i] + 10 * 3329) mod 3329
```

The shifted expression is an independent canonical modular oracle. The harness also checks frame properties showing that the separate second operand and saved source objects remain unchanged.

## Result

- Raw CBMC exit code: 0
- CProver status: success
- SAT result: UNSATISFIABLE
- `VERIFICATION SUCCESSFUL`: present
- Total properties: 361
- Successful: 361
- Failed: 0
- Other/unknown: 0
- Confirmed theorem-relevant reachable properties: 89/89 successful
- Unrelated retained-model properties not counted as SUB-T1 evidence: 272

## Completeness boundary

The relevant fixed loops were identified in the accepted preflight and explicitly unwound. Coefficient loops use bound 257, including the terminating check; one-element helper loops use bound 2. `--unwinding-assertions` remained enabled. The result is therefore complete for this frozen finite GOTO model and recorded assumptions, not a claim about every compiler, architecture, source revision, or implementation.

## Important modelling boundary

The theorem covers only input coefficient pairs satisfying:

```text
INT16_MIN <= (int32_t)A[i] - (int32_t)B[i] <= INT16_MAX
```

It does not cover arbitrary signed-16-bit pairs whose direct production subtraction would require a non-representable `int16_t` result.

## Body-level status

The accepted preflight records:

- production `poly.c` unchanged;
- frozen theorem harness unchanged;
- production bodies retained;
- no function-contract abstraction;
- no loop contracts applied;
- no expanded contract symbols in the model;
- narrowly scoped handling of one implementation-defined conversion check; and
- a separately supplied zero-valued environment blocker.

## Provenance correction

The originally distributed runner had `mlkem_poly_sub_cleanroom` in `BASE`; the executed runner corrected it to `mlk_poly_sub_cleanroom`. The complete diff is in `12_RUNNER_DIFF.txt`. It is the only textual difference.

## Top-level review files

1. `01_README_AND_THEOREM_SCOPE.md` — this scope summary.
2. `02_SUB_T1_HARNESS.c` — exact frozen harness.
3. `03_EXECUTED_RUNNER.sh` — exact executed runner.
4. `04_CBMC_COMMAND.txt` — exact command.
5. `05_ASSUMPTIONS_AND_ASSERTIONS.md` — exact assumptions, oracle and assertions.
6. `06_PREFLIGHT_REPORT.txt` — model-construction and preflight evidence.
7. `07_PROPERTY_INVENTORY.json` — deterministic JSON derivative of the frozen preflight inventory.
8. `08_CBMC_COMPLETE_RESULT.json` — complete raw CBMC JSON.
9. `09_REACHABLE_PROPERTY_CLASSIFICATION.md` — complete 89-property classification.
10. `10_GOTO_MODEL_VALIDATION.txt` — all validator gates and hashes.
11. `11_SOURCE_AND_EVIDENCE_MANIFEST.txt` — packet inventory and original-evidence map.
12. `12_RUNNER_DIFF.txt` — complete distributed/executed runner diff.
13. `13_ENVIRONMENT_AND_TOOL_VERSIONS.txt` — OS, compiler, CBMC and resource record.
14. `14_NOVELTY_COMPARISON.md` — repository comparison and cautious wider boundary.
15. `15_INDEPENDENT_EVIDENCE_REVIEW.md` — preserved independent acceptance review.
16. `SHA256SUMS` — hashes for every packet file except itself.

## Supporting directories

- `raw_archives/` — original uploaded final-result and preflight archives with sidecars.
- `raw_evidence/` — extracted raw outputs, manifests and selected preflight records.
- `model/` — frozen full and reachable-only GOTO binaries.
- `provenance/` — source-only clean-room packet, source manifest, preregistration, architecture freeze and sidecars.
- `repository_comparison/` — exact frozen repository harness and Makefile.
- `runner_provenance/` — both runner versions.

## Questions for supervisor review

1. Is the theorem scientifically meaningful at MSc level under the stated representability and machine-model boundaries?
2. Is “body-level CBMC semantic-composition artefact” accurate terminology?
3. Is the oracle formulation appropriate and sufficiently independent?
4. Is the reachable 89-property classification method acceptable?
5. Does the one-line path correction require a rerun, despite all frozen evidence being revalidated before execution?
6. Is the proposed contribution wording in `14_NOVELTY_COMPARISON.md` sufficiently cautious?
7. Which non-vacuity, coverage, mutation, or related theorem evidence should be completed before thesis inclusion?

## Integrity verification

From inside the unzipped packet directory, run:

```bash
sha256sum --check SHA256SUMS
```

The original nested archives have their own sidecar files and internal manifests.
