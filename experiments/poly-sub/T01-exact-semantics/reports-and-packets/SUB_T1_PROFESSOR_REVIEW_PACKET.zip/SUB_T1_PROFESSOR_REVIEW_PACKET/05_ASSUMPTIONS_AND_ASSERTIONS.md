# SUB-T1 Assumptions and Assertions

## Exact `__CPROVER_assume` statements

The frozen harness contains exactly two syntactic assumption statements, both inside the 256-coefficient loop:

```c
__CPROVER_assume(d >= (int32_t)INT16_MIN);
__CPROVER_assume(d <= (int32_t)INT16_MAX);
```

where:

```c
d = (int32_t)saved_A0.coeffs[i] -
    (int32_t)saved_B0.coeffs[i];
```

Semantically, these assumptions apply to every coefficient `i = 0..255`. They restrict SUB-T1 to input pairs whose direct mathematical difference is representable in `int16_t`.

## Object and input construction

`A0` and `B0` are separate local `mlk_poly` objects. Every coefficient is assigned an independent nondeterministic `int16_t` value. `L` and `LB` are also separate local objects initialized by value from `A0` and `B0`. Consequently, the production calls use distinct valid objects:

```c
mlk_poly_sub(&L, &LB);
mlk_poly_reduce(&L);
```

No explicit pointer-validity or non-aliasing `__CPROVER_assume` is used. Validity and separation arise from the harness's concrete local-object construction.

## Checked machine-model assertions — not assumptions

The harness checks, rather than assumes:

1. `CHAR_BIT == 8`.
2. `short` width is 16 bits.
3. `int` width is 32 bits.
4. `int16_t` width is 16 bits.
5. `int32_t` width is 32 bits.
6. pointer width is 64 bits.
7. signed right shift of `-1` is arithmetic.
8. signed right shift of odd negative `-3` preserves the expected sign result.

## Checked parameter-binding assertions — not assumptions

```c
__CPROVER_assert(MLKEM_N == FIPS_N, ...);
__CPROVER_assert(MLKEM_Q == FIPS_Q, ...);
```

with independent constants:

```c
#define FIPS_N 256u
#define FIPS_Q 3329
```

## Exact semantic assertions

For every coefficient after retained production subtraction and reduction:

```c
__CPROVER_assert(L.coeffs[i] >= 0,
                 "SUB_T1_SEMANTIC: output must be non-negative");
__CPROVER_assert(L.coeffs[i] < FIPS_Q,
                 "SUB_T1_SEMANTIC: output must be below FIPS_Q");
__CPROVER_assert((uint32_t)L.coeffs[i] == expected,
                 "SUB_T1_SEMANTIC: output must equal independent canonical oracle");
```

The exact independent oracle is:

```c
d = (int32_t)saved_A0.coeffs[i] -
    (int32_t)saved_B0.coeffs[i];
shifted = (uint32_t)(d + (int32_t)(10 * FIPS_Q));
expected = shifted % (uint32_t)FIPS_Q;
```

Because `d` is constrained to `[-32768,32767]`, adding `10 * 3329 = 33290` makes the shifted value non-negative. Adding a multiple of 3329 does not change the residue modulo 3329.

## Exact frame assertions

After `mlk_poly_sub`:

- `LB` equals `LB_before_sub` coefficientwise.
- `A0` equals `saved_A0` coefficientwise.
- `B0` equals `saved_B0` coefficientwise.

After `mlk_poly_reduce`:

- `LB` equals `LB_before_reduce` coefficientwise.
- final `LB` equals `saved_B0` coefficientwise.
- final `A0` equals `saved_A0` coefficientwise.
- final `B0` equals `saved_B0` coefficientwise.

## Assertions inventory

The 20 explicit assertion properties comprise:

- 8 machine-model assertions;
- 2 parameter-binding assertions;
- 3 frame assertions after subtraction;
- 3 semantic assertions after reduction; and
- 4 final frame assertions.

All 20 returned `SUCCESS`.

## Environment/model restrictions

The accepted model uses:

- frozen commit `d9613cf60de3132d32475c102d8c2781d84feb34`;
- `MLK_CONFIG_PARAMETER_SET=768`;
- portable C through `MLK_CONFIG_NO_ASM=1`;
- custom zeroization integration through `MLK_CONFIG_CUSTOM_ZEROIZE=1`;
- namespace `mlk_sub00g_r2`;
- a separate zero-valued volatile blocker definition;
- a narrowly scoped conversion-check pragma from `verify.h`;
- no function-contract abstraction;
- no applied loop contracts; and
- complete explicit unwinding with unwinding assertions enabled.

The pragma-scoping adapter suppresses the repository's intentionally implementation-defined conversion check only where `verify.h` specifies that scope. It does not add a theorem assumption or replace a production function body.

## Explicitly not assumed

The harness does not assume that inputs are canonical, non-negative, small, already equivalent modulo `q`, or that the result has the desired value. It does not assume the semantic postcondition.
