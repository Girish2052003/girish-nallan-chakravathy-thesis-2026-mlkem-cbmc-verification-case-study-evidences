#include <stdint.h>

#include "cbmc.h"
#include "common.h"

#define T3_Q ((int64_t)3329)
#define T3_R ((int64_t)65536)
#define T3_HALF ((int64_t)1665)
#define T3_MONTGOMERY_ONE ((int16_t)-1044)

extern int16_t nondet_int16_t(void);
int16_t mlk_fqmul(int16_t a, int16_t b);

static int16_t t3_centered(int64_t value)
{
  int64_t remainder;

  remainder = value % T3_Q;

  if (remainder > (T3_HALF - 1))
  {
    remainder -= T3_Q;
  }

  if (remainder < -(T3_HALF - 1))
  {
    remainder += T3_Q;
  }

  return (int16_t)remainder;
}

static void assume_signed_canonical(int16_t value)
{
  __CPROVER_assume((int64_t)value > -T3_HALF);
  __CPROVER_assume((int64_t)value < T3_HALF);
}

void harness(void)
{
  int16_t x;
  int16_t y;
  int16_t z;

  int16_t xy;
  int16_t yx;

  int16_t x_zero;
  int16_t zero_y;

  int16_t x_mont_one;
  int16_t mont_one_x;

  int16_t normalized_y_plus_z;
  int16_t distributive_left;
  int16_t distributive_xy;
  int16_t distributive_xz;
  int16_t distributive_right;

  int16_t normalized_xy;
  int16_t normalized_yz;
  int16_t associative_left;
  int16_t associative_right;

  x = nondet_int16_t();
  y = nondet_int16_t();
  z = nondet_int16_t();

  /*
   * All three operands are canonical because every value appears as
   * the second operand of mlk_fqmul in at least one checked law.
   */
  assume_signed_canonical(x);
  assume_signed_canonical(y);
  assume_signed_canonical(z);

  xy = mlk_fqmul(x, y);
  yx = mlk_fqmul(y, x);

  __CPROVER_assert(
      xy == yx,
      "MONT-T3.P2.exact_commutativity_for_canonical_operands");

  x_zero = mlk_fqmul(x, 0);
  zero_y = mlk_fqmul(0, y);

  __CPROVER_assert(
      x_zero == 0 && zero_y == 0,
      "MONT-T3.P3.zero_annihilation");

  __CPROVER_assert(
      ((t3_centered((int64_t)xy) == 0) ==
       (x == 0 || y == 0)),
      "MONT-T3.P3.zero_product_reflection");

  __CPROVER_assert(
      t3_centered(T3_R) == T3_MONTGOMERY_ONE,
      "MONT-T3.S3.montgomery_one_constant_check");

  x_mont_one =
      mlk_fqmul(x, T3_MONTGOMERY_ONE);

  mont_one_x =
      mlk_fqmul(T3_MONTGOMERY_ONE, x);

  __CPROVER_assert(
      t3_centered((int64_t)x_mont_one) == x,
      "MONT-T3.P4.right_montgomery_one_identity");

  __CPROVER_assert(
      t3_centered((int64_t)mont_one_x) == x,
      "MONT-T3.P4.left_montgomery_one_identity");

  normalized_y_plus_z =
      t3_centered((int64_t)y + (int64_t)z);

  distributive_left =
      t3_centered(
          (int64_t)mlk_fqmul(
              x,
              normalized_y_plus_z));

  distributive_xy = mlk_fqmul(x, y);
  distributive_xz = mlk_fqmul(x, z);

  distributive_right =
      t3_centered(
          (int64_t)distributive_xy +
          (int64_t)distributive_xz);

  __CPROVER_assert(
      distributive_left == distributive_right,
      "MONT-T3.P5.distributivity_after_normalization");

  normalized_xy =
      t3_centered(
          (int64_t)mlk_fqmul(x, y));

  normalized_yz =
      t3_centered(
          (int64_t)mlk_fqmul(y, z));

  associative_left =
      t3_centered(
          (int64_t)mlk_fqmul(
              normalized_xy,
              z));

  associative_right =
      t3_centered(
          (int64_t)mlk_fqmul(
              x,
              normalized_yz));

  __CPROVER_assert(
      associative_left == associative_right,
      "MONT-T3.P6.associativity_after_normalization");
}
