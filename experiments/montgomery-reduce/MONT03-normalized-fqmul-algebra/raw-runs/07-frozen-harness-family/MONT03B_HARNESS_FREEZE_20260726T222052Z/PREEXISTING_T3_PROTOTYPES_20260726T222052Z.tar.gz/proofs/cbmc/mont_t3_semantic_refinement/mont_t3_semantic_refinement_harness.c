#include <stdint.h>

#include "cbmc.h"
#include "common.h"

#define T3_Q ((int64_t)3329)
#define T3_R ((int64_t)65536)
#define T3_R_INV ((int64_t)169)
#define T3_HALF ((int64_t)1665)

extern int16_t nondet_int16_t(void);
int16_t mlk_fqmul(int16_t a, int16_t b);

static int16_t t3_centered(int64_t value)
{
  int64_t remainder;

  remainder = value % T3_Q;

  if (remainder > (T3_HALF - 1))
  {
    remainder -= T3_Q;
  }

  if (remainder < -(T3_HALF - 1))
  {
    remainder += T3_Q;
  }

  return (int16_t)remainder;
}

void harness(void)
{
  int16_t a;
  int16_t b;
  int16_t actual;
  int16_t independent_oracle;

  a = nondet_int16_t();
  b = nondet_int16_t();

  /*
   * Source contract:
   *   a may be any int16_t;
   *   b must be signed canonical.
   */
  __CPROVER_assume((int64_t)b > -T3_HALF);
  __CPROVER_assume((int64_t)b < T3_HALF);

  actual = mlk_fqmul(a, b);

  /*
   * Independent modular specification:
   *
   *   R^-1 mod q = 169
   *   fqmul(a,b) = a*b*R^-1 mod q
   *
   * This oracle does not invoke mlk_montgomery_reduce.
   */
  independent_oracle =
      t3_centered(
          (int64_t)a *
          (int64_t)b *
          T3_R_INV);

  __CPROVER_assert(
      ((T3_R % T3_Q) * T3_R_INV) % T3_Q == 1,
      "MONT-T3.S1.independent_R_inverse_check");

  __CPROVER_assert(
      (int64_t)actual > -T3_Q &&
          (int64_t)actual < T3_Q,
      "MONT-T3.S2.production_output_bound");

  __CPROVER_assert(
      t3_centered((int64_t)actual) ==
          independent_oracle,
      "MONT-T3.P1.independent_multiplication_semantic_refinement");
}
