#include <stdint.h>

#include "cbmc.h"
#include "common.h"

#define T3_HALF ((int64_t)1665)

extern int16_t nondet_int16_t(void);
int16_t mlk_fqmul(int16_t a, int16_t b);

void harness(void)
{
  int16_t arbitrary_a;
  int16_t canonical_b;
  int16_t canonical_x;
  int16_t canonical_y;
  int16_t result;

  arbitrary_a = nondet_int16_t();
  canonical_b = nondet_int16_t();

  __CPROVER_assume((int64_t)canonical_b > -T3_HALF);
  __CPROVER_assume((int64_t)canonical_b < T3_HALF);

  result = mlk_fqmul(arbitrary_a, canonical_b);
  (void)result;

  __CPROVER_assert(
      0,
      "MONT-T3.CONTROL.semantic_domain_reachable");

  canonical_x = nondet_int16_t();
  canonical_y = nondet_int16_t();

  __CPROVER_assume((int64_t)canonical_x > -T3_HALF);
  __CPROVER_assume((int64_t)canonical_x < T3_HALF);
  __CPROVER_assume((int64_t)canonical_y > -T3_HALF);
  __CPROVER_assume((int64_t)canonical_y < T3_HALF);

  result = mlk_fqmul(canonical_x, canonical_y);
  (void)result;

  __CPROVER_assert(
      0,
      "MONT-T3.CONTROL.algebra_domain_reachable");
}
